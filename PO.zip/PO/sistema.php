<?php
class Sistema
{
    function getIp()
    {
        return $_SERVER['REMOTE_ADDR'];
    }
    function getUrl()
    {
        return $_SERVER['HTTP_HOST']; // não é regra ter return pode ser echo 
    }
}
class Dd
{
    function numRows()
    {
        return 20;
    }
}
class Pessoa{ // precisa chamar a classe 
    var $nome; // coloca o var dentro da classe, se tiver fora nao precisa colocar var na frente 

    function imc($altura, $peso, $nome = "Pedro")
    { // se não colocar nenhum nome fica Julio 
        $imc = $peso / ($altura * $altura);
        $teste = '';
        return "<br>IMC de " . $nome . " : " . number_format($imc, 2); //number_format para numeros inteiros... 2 casas decimais
    }
    function correr()
    {
        return "corrida";
    }
    function setNome($nome)
    {
        $this->nome = $nome;
    }
    function getNome(){
       return $this->nome;
    }
}

class cachorro extends Pessoa{

}
    $cachorro = new cachorro();
        echo $cachorro->correr();