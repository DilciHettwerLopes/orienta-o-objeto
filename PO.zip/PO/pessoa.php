<?php
require "sistema.php";
$pessoa = new Pessoa();
echo $pessoa->imc(1.72, 110, 'Gabriel');
echo $pessoa->imc(1.88, 90,'Douglas');
echo $pessoa->imc(1.70, 80); 
echo $pessoa->imc(1.90, 100, 'Anderson');

$pessoa->setNome('Aline Silva');
echo $pessoa->getNome();