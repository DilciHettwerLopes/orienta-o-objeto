<?php
session_start();
require __DIR__ . '/inc/class.crud.php';
require __DIR__ . '/inc/class.file.php';

$contato = new CRUD();
$file = new File();
$table = 'contatos';


if ($_GET['acao'] == 'cadastrar') {
    $_SESSION['mensagem'] = 'Falha ao cadastrar';
    $file->setDir('cursos');
    $arquivo = $file->upload($_FILES['arquivo']);
    if ($arquivo) {
        $_POST['arquivo'] = $arquivo;
        if ($contato->create($table, $_POST) > 0) {
            $_SESSION['mensagem'] = 'Sucesso ao cadastrar';
        }
    }
    header('Location:contatos.php');
}

if ($_GET['acao'] == "apagar" && is_numeric($_GET['id'])) {
    $contato->delete($table, 'id=' . $_GET['id']);
    header('Location:contatos.php');
}

if ($_GET['acao'] == "atualizar" && is_numeric($_GET['id'])) {
    $_SESSION['mensagem'] = 'Falha ao atualizar';
    if ($contato->update($table, $_POST, 'id=' . $_GET['id']) > 0) {
        $_SESSION['mensagem'] = 'Sucesso ao atualizar';
    }
    header('Location:contatos.php');
}
