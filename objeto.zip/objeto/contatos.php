<?php
session_start();
require __DIR__ . '/inc/class.crud.php';
require __DIR__ . '/inc/class.file.php';
$contatos = new crud();
$title = 'Cadastrar';

if (@$_GET['acao'] == "atualizar") {
    $title = 'Atualizar';
   
    $contato = $contatos->read('contatos', 'id=' . $_GET['id']);
  
}
?>
<fieldset>
    <legend><?=$title?></legend>
    <form enctype="multipart/form-data" method="post" action="acoes.php?acao=<?=strtolower($title)?>&id=<?=@$_GET['id']?>" > 
        <input type="text" name="nome" value="<?=@$contato[0]->nome?>" placeholder="Digite o nome"> <br>
        <input type="email" name="email" value="<?=@$contato[0]->email?>" placeholder="Digite o e-mail"> <br>
        <label for="imagem">Imagem: </label>
        <input type="file" name="arquivo" value="<?=@$file[0]->arquivo?>" placeholder="Escolha o arquivo"> <br>
        <input type="submit" value="Gravar"> <br>
    </form>

</fieldset>
<?php
if (!empty($_SESSION['mensagem'])) {
    echo $_SESSION['mensagem'];
    unset($_SESSION['mensagem']);
}
?>

<table border="1" width="100%" style="margin-top: 10px;">
    <thead>
        <th>ID</th>
        <th>Nome</th>
        <th>Email</th>
        <th>Opções</th>
    </thead>
    <tbody>
        <tr>
            <?php
            
            $busca = $contatos->read('contatos');
            if ($busca) {
                foreach ($busca as $item) {
                    echo '<tr>';
                    echo '<td>' . $item->id . '</td>';
                    echo '<td>' . $item->nome . '</td>';
                    echo '<td>' . $item->email . '</td>';
                //echo '<td>' . $item->arquivo . '</td>';
                    echo '<td>';
                    echo '<a href="acoes.php?acao=apagar&id=' . $item->id . '">';
                    echo 'Apagar';
                    echo '</a>';
                    echo " | ";

                    echo '<a href="contatos.php?acao=atualizar&id=' . $item->id . '">';
                    echo 'Alterar';
                    echo '</a>';
                    echo '</td>';
                    echo '</tr>';
                }
            } else {
                echo '<tr><td colspan="4">Nada encontrado</td></tr>';  //colspan mescla as linhas 

            }

            ?>
        </tr>
    </tbody>
</table>