<?php

class File{
    private $dir = 'uploads'; //diretório padrão = default diretory

    public function __construct() {
        $this->createDir($this->dir);
    }
    public function createDir($dir) {
    if(!is_dir($this->dir)) {
        mkdir($this->dir);
        }
    }
    public function setDir($dir) {
        $this->dir = $dir;
        $this->createDir($this->dir);
    }
   

    public function upload($file) {
        $name = md5(time()) . '.' . pathinfo(basename($file["name"]), PATHINFO_EXTENSION);
        if (move_uploaded_file($file['tmp_name'], $this->dir. '/' . $name)){
                return $name;
        }else{
                return false;
            }
        }
    }

    //public function delete(){}