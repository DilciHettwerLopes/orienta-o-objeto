<?php
//http://dontpad.com/senacsmo/gabriel
require 'class.db.php';

class CRUD extends DB
{
    public function create($table, $fields)
    {
        $campos = implode(',', array_keys($fields)); // colunas como no sql 
        $valores = implode("','", array_values($fields)); // valores como no sql 
        mysqli_query($this->con, "insert into $table ($campos) VALUES ('$valores')"); // coloca a tabela e um array (dados)
        return mysqli_affected_rows($this->con);
    }
     public function read($table,$where=null){
        if(!empty($where)){
            $where = ' WHERE '.$where;
        }
        $query = mysqli_query($this->con,"SELECT * FROM $table $where");
        $result = [];
        while($row = mysqli_fetch_object($query)){
            $result[] = $row;
        }
        return $result;
    }

    public function update($table,$fields,$where){
        $set = [];
        foreach ($fields as $field=>$value){
            $set[] = $field.'="'.$value.'"';
        }
        $fields = implode(',',$set);
        $update = 'UPDATE ' . $table . ' SET ' . $fields . ' WHERE ' . $where;
        mysqli_query($this->con, $update);
        return mysqli_affected_rows($this->con);
    }

    public function delete($table,$where)    {
        if(!empty($table) && !empty($where)){
        return mysqli_query($this->con, "DELETE FROM $table where $where");
        mysqli_affected_rows($this->con);
        } else{
            return false;
        }
    }
}

$contato = [ 'nome' => "Dilci", 'email' => "dilcylopes@gmail.com"]; //array
$contato2= [ 'nome' => "Maria", 'email' => "maria@gmail.com"]; //array
$contato3 = array('nome'=>'Pedro','email'=>'pedro@sadasd.com');

// insert into contatos (nome,email) VALUES ("Dilci", "dilcylopes@gmail.com")
//$crud = new CRUD();
//$crud ->create('contatos', $contato);

//echo $crud ->delete('contatos', 'id=1');
//$crud -> disconnect();
//$crud = new CRUD(); // precisa estanciar novamente o crud 
// $crud -> create('contatos', $contato);

//$crud->update('contato','contato2','id=2');
//$retorno = $crud ->read('contatos');
//foreach ($retorno as $item){
//echo $item->nome;
//echo $item->email;
